#ifndef UTILS_HPP
#define UTILS_HPP

typedef long long ll;

#define PATH_TYPE 0
#define PORTAL_TYPE 1

#endif